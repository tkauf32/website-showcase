---
title: "Widget X (EDC Tool)"
tags: ["edc","mechanical"]
rating: 4.0
affiliate_url: "https://example.com/your-affiliate-link"
poster: /models/example-widget.jpg
---

Why I like it, pros/cons, alternatives.
