---
title: "Example Widget"
tags: ["utility", "petg"]
printer: "Bambu X1C"
material: "PETG"
time_to_print: "3h 10m"
rating: 4.5
poster: /models/example-widget.jpg
model_url: /models/example-widget.glb
download_url: /models/example-widget.glb
---

Short notes about this model (supports, infill, orientation).
