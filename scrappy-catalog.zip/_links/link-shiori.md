---
title: "Shiori (self-hosted bookmarks)"
tags: ["links","selfhosted"]
poster:
---

I use it to track interesting builds. Public list here: https://example.com
